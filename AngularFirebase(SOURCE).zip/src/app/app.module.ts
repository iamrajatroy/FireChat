import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import {EmojiPickerModule} from 'ng-emoji-picker';
import {NgxAutoScrollModule} from "ngx-auto-scroll";

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { ChatComponent } from './components/chat/chat.component';

import {appRoutes} from './routes';
import { ChatFormComponent } from './components/chat/chat-form/chat-form.component';
import { FeedComponent } from './components/chat/feed/feed.component';
import { UserListComponent } from './components/chat/user-list/user-list.component';
import { CurrentUserComponent } from './components/chat/current-user/current-user.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    ChatComponent,
    ChatFormComponent,
    FeedComponent,
    UserListComponent,
    CurrentUserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    EmojiPickerModule,
    NgxAutoScrollModule
  ],
  providers: [
  ],
  bootstrap: [AppComponent]

})
export class AppModule {
}
