import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ChatService } from '../../../services/chat-service/chat.service';
import { ChatMessage } from '../../../models/chat.model';
import { AuthService } from '../../../services/auth-service/auth.service';
import { MessagingService } from '../../../services/chat-service/messaging.service';



@Component({
  selector: 'app-chat-form',
  templateUrl: './chat-form.component.html',
  styleUrls: ['./chat-form.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ChatFormComponent implements OnInit {

  message: string = '';
  userName: any;
  userEmail: string;
  photoUrl: string;
  public openPopup: Function;

  constructor(private auth: AuthService, private chat: ChatService, private msg: MessagingService) {
  }

  ngOnInit() {
    this.auth.user.subscribe(user => {
      if (user !== null) {
        this.userName = user.displayName;
        this.userEmail = user.email;
        this.photoUrl = user.photoURL;
      }
    });

    this.msg.messageIsClicked.subscribe(userName => {
      if (userName != null && userName != '') {
        this.message = '@'.concat(userName).concat(': ');
      }
    })

  }

  send() {
    if (this.message !== null && this.message !== '') {
      const messageObj = new ChatMessage(this.userName, this.userEmail, this.photoUrl, this.message, this.getCurrentTimeStamp());
      this.chat.sendMessage(messageObj);
      this.openPopup(false);
      this.message = '';
    }
  }

  getCurrentTimeStamp() {
    var date = new Date();
    var myDate = date.getFullYear() + "/" + date.getMonth() + "/" + date.getDate();
    var myTime = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    return myDate + ' ' + myTime;
  }

  handleSubmit(event) {
    if (event.keyCode === 13) {
      this.send();
    }
  }

  setPopupAction(fn: any) {
    this.openPopup = fn;
  }

}
