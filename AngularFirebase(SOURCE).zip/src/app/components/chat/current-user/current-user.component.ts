import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth-service/auth.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-current-user',
  templateUrl: './current-user.component.html',
  styleUrls: ['./current-user.component.css']
})
export class CurrentUserComponent implements OnInit {

  currentUser: any;

  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.auth.user.subscribe(user => {
      if (user !== null) {
        this.currentUser = new User(user.displayName, user.email, user.photoURL);
        this.currentUser.setKey(user.uid);
      }
    })
  }

  signOut() {
    this.auth.logout(this.currentUser.getKey());
  }

}
