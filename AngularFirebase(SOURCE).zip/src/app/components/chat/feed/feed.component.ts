import { Component, OnInit } from '@angular/core';
import { ChatService } from '../../../services/chat-service/chat.service';
import { ChatMessage } from '../../../models/chat.model';
import { AuthService } from '../../../services/auth-service/auth.service';
import { MessagingService } from '../../../services/chat-service/messaging.service';


@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.css']
})
export class FeedComponent implements OnInit {

  messages: ChatMessage[] = [];

  email: string;

  constructor(private chat: ChatService, private auth: AuthService, private msg: MessagingService) { }

  ngOnInit() {

    this.auth.user.subscribe(user => {
      if (user !== null) {
        this.email = user.email;
      }
    })

    this.chat.messages.subscribe(messages => {
      if (messages.length > 0) {
        this.messages = messages;
      }
    })
  }

  messageClicked(userName: string) {
    this.msg.messageClicked(userName);
  }


}
