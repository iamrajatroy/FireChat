import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../services/auth-service/auth.service';
import { User } from '../../../models/user.model';
import { user } from 'rxfire/auth/dist/auth';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users: User[];
  currentUser: any;

  constructor(private auth: AuthService) { }

  ngOnInit() {

    this.auth.user.subscribe(user => {
      if (user !== null) {
        this.currentUser = new User(user.displayName, user.email, user.photoURL);
        this.currentUser.setKey(user.uid);
      }
    })
    
    this.auth.userList.subscribe(users => {
      if(users.length > 0) 
      {
        this.users = users;
      }
    })
  }

}
