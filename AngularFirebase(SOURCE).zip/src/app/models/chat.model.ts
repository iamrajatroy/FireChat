export class ChatMessage {
    $key?: string;
    userName?: string;
    userEmail?: string;
    photoUrl?: string;
    message?: string;
    timeSent?: string;

    constructor(userName: string, userEmail: string, photoUrl: string, message: string, timeSent: string) {
        this.userName = userName;
        this.message = message;
        this.timeSent = timeSent;
        this.userEmail = userEmail;
        this.photoUrl = photoUrl;
    }

    getUserName() {
        return this.userName;
    }

    getMessage() {
        return this.message;
    }

    getTimeSent() {
        return this.timeSent;
    }

    setKey(key: string) {
        this.$key = key;
    }

}