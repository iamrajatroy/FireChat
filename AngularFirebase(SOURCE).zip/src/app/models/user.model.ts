export class User {
    $key?: string;
    userName?: string;
    userEmail?: string;
    photoUrl?: string;

    constructor(userName: string, userEmail: string, photoUrl: string) {
        this.userName = userName;
        this.userEmail = userEmail;
        this.photoUrl = photoUrl;
    }

    setKey(id: string) {
        this.$key = id;
    }

    getKey() {
        return this.$key;
    }

}