import { Injectable, Output, EventEmitter } from '@angular/core';

import { authState } from 'rxfire/auth';
import * as firebase from 'firebase';
import { User } from '../../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  DB_URL: string = 'https://angularfirebasepractice1.firebaseio.com/';

  @Output() user: EventEmitter<any> = new EventEmitter();
  @Output() loginEvent: EventEmitter<boolean> = new EventEmitter();
  @Output() userList: EventEmitter<User[]> = new EventEmitter();

  constructor() {
    this.fetchAllUsers();
    authState(firebase.auth()).subscribe(user => {
      if (user !== null) {
        this.emitEvent(true, user);
        this.saveToDB();
      } else {
        this.emitEvent(false, null);
      }
    });
  }

  deleteFromDB(uid: string) {
    firebase.app().database(this.DB_URL).ref("/users/" + uid).remove();
  }

  saveToDB() {
    var currentUser = firebase.auth().currentUser;
    var userId = currentUser.uid;
    // const user = new User(currentUser.displayName, currentUser.email, currentUser.photoURL);
    firebase.app().database(this.DB_URL).ref("/users/" + userId).set({
      "userName": currentUser.displayName,
      "email": currentUser.email,
      "photoUrl": currentUser.photoURL
    });
  }

  fetchAllUsers() {
    firebase.app().database(this.DB_URL).ref("/users")
      .on('value', snapshot => {
        var usrs = [];
        snapshot.forEach((childSnapshot) => {
          var childKey = childSnapshot.key;
          var childData = childSnapshot.val();
          var user = new User(childData.userName, childData.email, childData.photoUrl);
          usrs.push(user);
        });
        // emit users
        this.refreshUserList(usrs);
      })
  }

  refreshUserList(usrs: User[]) {
    this.userList.emit(usrs);
  }

  login() {
    var provider = new (firebase.auth as any).GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider);
  }

  logout(uid: string) {
    this.deleteFromDB(uid);
    firebase.auth().signOut();
  }

  getUser() {
    return this.user;
  }

  emitEvent(value: boolean, user: any) {
    this.user.emit(user);
    this.loginEvent.emit(value);
  }

  getLoginEvent() {
    return this.loginEvent;
  }

}
