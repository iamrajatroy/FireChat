import { Injectable, EventEmitter } from '@angular/core';
import * as firebase from 'firebase';
import { ChatMessage } from '../../models/chat.model';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  DB_URL: string = 'https://angularfirebasepractice1.firebaseio.com/';

  messages: EventEmitter<ChatMessage[]> = new EventEmitter();

  constructor() {
    this.getMessages();
  }

  sendMessage(message: ChatMessage) {
    firebase.app().database(this.DB_URL).ref('messages').push({
      "message": message.message,
      "userName": message.userName,
      "timeSent": message.timeSent,
      "userEmail": message.userEmail,
      "photoUrl": message.photoUrl
    });
  }

  getMessages() {
    firebase.app().database(this.DB_URL).ref('messages')
      .limitToLast(25)
      .on('value', (snapshot) => {
        var msgs = [];
        snapshot.forEach((childSnapshot) => {
          var childKey = childSnapshot.key;
          var childData = childSnapshot.val();
          var chatMessage = new ChatMessage(childData.userName, childData.userEmail, childData.photoUrl, childData.message, childData.timeSent);
          chatMessage.setKey(childKey);
          msgs.push(chatMessage);
        });
        //emit messages
        this.refreshMessages(msgs);
      })

  }

  refreshMessages(msgs: ChatMessage[]) {
    this.messages.emit(msgs);
  }


}
