import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessagingService {

  @Output() messageIsClicked: EventEmitter<string> = new EventEmitter();

  constructor() { }

  messageClicked(userName: string) {
    this.messageIsClicked.emit(userName);
  }

}
