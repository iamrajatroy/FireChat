export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD7UfZAIE_yU0U1V3qWA2EpjTKcPwPAJg4",
    authDomain: "angularfirebasepractice1.firebaseapp.com",
    databaseURL: "https://angularfirebasepractice1.firebaseio.com",
    projectId: "angularfirebasepractice1",
    storageBucket: "angularfirebasepractice1.appspot.com",
    messagingSenderId: "135347181410"
  }
};
